$(document).ready(function(){
  $("#hello").click(function(){
    alert("The paragraph was clicked.");
  });
});
