package com.gym.S3Fitness.sql;

public interface AppSQL {

	 public String getSqlQuery(String property);
	 public String getDatabaseProperty(String property);
}
