package com.gym.S3Fitness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3FitnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
